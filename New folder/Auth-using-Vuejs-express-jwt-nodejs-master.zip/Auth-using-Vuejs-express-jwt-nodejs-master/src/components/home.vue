<template>
	<div>
		<h1 style="text-align:center; margin-top:200px; font-size:100px"><b>Hello there!</b></h1>
	</div>
</template>
