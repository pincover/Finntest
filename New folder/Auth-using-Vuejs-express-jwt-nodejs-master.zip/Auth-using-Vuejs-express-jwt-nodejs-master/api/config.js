module.exports = {
  secret: 'SomeSecretString',
};